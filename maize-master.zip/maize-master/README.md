# Pokémon Maize (Hack of Pokémon Red)

This is a fork of the [**Pokémon Red disassembly**](https://github.com/iimarckus/pokered) used to create a new game!

It uses the following ROM as a base:

	Pokemon Red (UE) [S][!].gb
	(MD5: 3d45c1ee9abd5738df46d2bdda8b57dc)

To set up the repository, see [**INSTALL.md**](INSTALL.md).


## See also

* Disassembly of [**Pokémon Crystal**](https://github.com/kanzure/pokecrystal)

* irc: **nucleus.kafuka.org** [**#skeetendo**](https://kiwiirc.com/client/irc.nolimitzone.com/?#skeetendo)

